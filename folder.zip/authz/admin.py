from django.contrib import admin
from .models import *

admin.site.register(GeneralData)
admin.site.register(TypeOf)
admin.site.register(Studio)
admin.site.register(Demographic)
admin.site.register(Genre)
admin.site.register(Rating)
admin.site.register(Source)
admin.site.register(AdminChoices)